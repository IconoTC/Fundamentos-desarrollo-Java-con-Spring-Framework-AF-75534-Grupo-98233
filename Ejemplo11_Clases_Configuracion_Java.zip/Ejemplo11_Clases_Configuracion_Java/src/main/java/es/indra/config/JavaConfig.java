package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import es.indra.business.Aseguradora;
import es.indra.business.TallerMecanica;
import es.indra.business.TallerPintura;
import es.indra.models.Coche;

@Configuration
//@ImportResource("ruta/applicationContext.xml")
public class JavaConfig {
	
	@Bean   // Convierte el objeto Java que ha retornado el metodo en un bean de Spring
	public TallerPintura tallerPintura() {
		return new TallerPintura(); 
	}
	
	@Bean
	@Scope("singleton")
	@Lazy
	public TallerMecanica tallerMecanica() {
		TallerMecanica tallerMecanica = new TallerMecanica(); 
		return tallerMecanica;
	}
	
	@Bean
	public Coche coche() {
		return new Coche("1234-NLD", "A5");
	}
	
	@Bean
	public Aseguradora aseguradora() {
		Aseguradora aseguradora = new Aseguradora();
        aseguradora.setNombre("Mapfre");
        aseguradora.setTaller(tallerMecanica());
        return aseguradora;
	}

}

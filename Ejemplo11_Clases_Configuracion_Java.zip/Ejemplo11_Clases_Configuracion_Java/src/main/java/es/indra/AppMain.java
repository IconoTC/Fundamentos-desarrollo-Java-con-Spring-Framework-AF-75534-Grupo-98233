package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.config.JavaConfig;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el JavaConfig.class y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		ApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		// Recuperar el bean coche
		Coche coche = (Coche) contenedor.getBean("coche");   // id del bean coche
		
		// Recuperar el bean aseguradora
		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
		
		// Ejecutar
		aseguradora.arreglarCoche(coche);
	}

}

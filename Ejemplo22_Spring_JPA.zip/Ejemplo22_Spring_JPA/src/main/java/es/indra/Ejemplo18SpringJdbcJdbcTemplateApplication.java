package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo18SpringJdbcJdbcTemplateApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	// En los proyectos con Spring Boot, el metodo main esta dedicado
	// exclusivamente a levantar el contexto de Spring (crear el contenedor con los beans declarados)
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18SpringJdbcJdbcTemplateApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	@Override
	public void run(String... args) throws Exception {
		
		// Insertar nuevo producto
		dao.insertarProducto(new Producto(1, "Teclado", 29.95));
		dao.insertarProducto(new Producto(2, "Raton", 16));
		dao.insertarProducto(new Producto(3, "Pantalla", 129.50));
		
		// Consultar todos los productos
		dao.consultarTodos().forEach(System.out::println);
		
		// Buscar un producto
		System.out.println(dao.buscarProducto(2) + "------");
		
	}

}

package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.persistence.ProductosDAO;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

@Configuration
public class JavaConfig {
	
	@Bean
	public EntityManagerFactory entityManagerFactory() {
		return Persistence.createEntityManagerFactory("PU");
	}
	
	@Bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setEmf(entityManagerFactory() );
		return dao;
	}
	
}

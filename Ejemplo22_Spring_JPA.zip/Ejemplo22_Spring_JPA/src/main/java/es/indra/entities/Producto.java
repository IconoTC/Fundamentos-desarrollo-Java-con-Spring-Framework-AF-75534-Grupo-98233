package es.indra.entities;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity   // Esta clase es un mapeo entre los objetos y la tabla en la BBDD
@Table(name = "PRODUCTOS")
public class Producto implements Serializable{
	
	@Id  // PK simple
	@Column(name = "ID_PRODUCTO", nullable = false, unique = true)
	private int ID;
	
	@Column(name = "DESCRIPCION", length = 30)
	private String descripcion;
	
	@Column(name = "PRECIO")
	private double precio;
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(int iD, String descripcion, double precio) {
		super();
		ID = iD;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [ID=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
}

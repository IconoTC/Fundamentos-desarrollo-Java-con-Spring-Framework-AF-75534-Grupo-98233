package es.indra.persistence;

import java.util.List;

import es.indra.entities.Producto;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;

public class ProductosDAO {
	
	private EntityManagerFactory emf;
		
	public List<Producto> consultarTodos(){
		EntityManager em = emf.createEntityManager(); // Factoria dinamica
		List<Producto> lista = em.createQuery("select p from Producto p").getResultList();
		em.close();
		return lista;
	}
	
	public Producto buscarProducto(int id){
		EntityManager em = emf.createEntityManager(); 
		Producto producto = em.find(Producto.class, id);   // Buscar por PK
		em.close();
		return producto;
	}

	public boolean insertarProducto(Producto producto) {
		boolean insertado = false;
		
		EntityManager em = emf.createEntityManager(); 
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.persist(producto);
			et.commit();
			insertado = true;
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
		
		return insertado;
	}
	
	public EntityManagerFactory getEmf() {
		return emf;
	}
	
	public void setEmf(EntityManagerFactory emf) {
		this.emf = emf;
	}

}

package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.config.JavaConfig;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el JavaConfig.class y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		ApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		
	}

}

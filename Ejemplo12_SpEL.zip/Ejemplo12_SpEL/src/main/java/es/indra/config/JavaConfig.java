package es.indra.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
	
	/*
	 * crear 3 beans de cliente:
	 * 		crear cliente1
	 * 		crear cliente2 podeis utilizar propiedades del cliente1
	 * 		crear cliente3
	 * 
	 * crear un bean de la clase Pruebas:
	 * 		valorContador = incrementarContador() de Cliente
	 * 		importeCompras = si la cifraCompras del cliente1 es mayor que 12000000 le asignas esa y sino 12000000
	 * 		clientes = lista con los 3 clientes
	 * 
	 * crear un bean de la clase OperacionColecciones:
	 * 		mejoresClientes = cuya cifraCompras sea superior a 10 millones
	 * 		mejorCompra = cliente con la mejor cifraCompras
	 * 		peorCompra = cliente con la peor cifraCompras
	 * 		datos = proyeccion (nombre | nif)
	 * */

}

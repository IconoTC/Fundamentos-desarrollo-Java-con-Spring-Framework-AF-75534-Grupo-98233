package es.indra.business;

import java.util.List;

import es.indra.models.Cliente;

public class Pruebas {

	private int valorContador;
	private double importeCompras;
	private List<Cliente> clientes;

	public int getValorContador() {
		return valorContador;
	}

	public void setValorContador(int valorContador) {
		this.valorContador = valorContador;
	}

	public double getImporteCompras() {
		return importeCompras;
	}

	public void setImporteCompras(double importeCompras) {
		this.importeCompras = importeCompras;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

}

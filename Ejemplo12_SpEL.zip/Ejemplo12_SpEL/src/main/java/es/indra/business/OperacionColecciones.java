package es.indra.business;

import java.util.List;

import es.indra.models.Cliente;

public class OperacionColecciones {

	private List<Cliente> mejoresClientes;
	private List<String> datos;
	private Cliente mejorCompra;
	private Cliente peorCompra;

	public List<Cliente> getMejoresClientes() {
		return mejoresClientes;
	}

	public void setMejoresClientes(List<Cliente> mejoresClientes) {
		this.mejoresClientes = mejoresClientes;
	}

	public List<String> getDatos() {
		return datos;
	}

	public void setDatos(List<String> datos) {
		this.datos = datos;
	}

	public Cliente getMejorCompra() {
		return mejorCompra;
	}

	public void setMejorCompra(Cliente mejorCompra) {
		this.mejorCompra = mejorCompra;
	}

	public Cliente getPeorCompra() {
		return peorCompra;
	}

	public void setPeorCompra(Cliente peorCompra) {
		this.peorCompra = peorCompra;
	}

}

package es.indra.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import es.indra.models.Producto;

public class ProductosDAO {
	
	private NamedParameterJdbcTemplate template;
	private RowMapper<Producto> mapeadorProducto;
	
	
	public List<Producto> consultarTodos(){
		return template.query("select * from PRODUCTOS", mapeadorProducto);
	}
	
	public Producto buscarProducto(int id){
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("codigo", id);
		return template.queryForObject("select * from PRODUCTOS where ID=:codigo", parametros, mapeadorProducto);
	}

	public boolean insertarProducto(Producto producto) {
		boolean insertado = false;
		String sql = "insert into PRODUCTOS values (:codigo, :desc, :pre)";
		
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("codigo", producto.getID());
		parametros.put("desc", producto.getDescripcion());
		parametros.put("pre", producto.getPrecio());
		
		int registros = template.update(sql, parametros);
		if (registros == 1) {
			insertado = true;
			System.out.println("Producto insertado");
		}
		return insertado;
	}
	
	public void crearTabla() {		
		// Crear la tabla
		template.update("DROP TABLE PRODUCTOS if exists", (Map<String, Object>) null);
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		template.update(sql, (Map<String, Object>) null);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (:codigo, :desc, :pre)";
		for (int i = 1; i <= 5; i++) {
			Map<String, Object> parametros = new HashMap<>();
			parametros.put("codigo", i);
			parametros.put("desc", "Producto " + i);
			parametros.put("pre", i * 100);
			template.update(sql, parametros);
		}
	}
	
	public NamedParameterJdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(NamedParameterJdbcTemplate template) {
		this.template = template;
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}
	
}

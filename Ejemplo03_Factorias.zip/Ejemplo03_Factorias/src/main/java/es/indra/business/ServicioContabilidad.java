package es.indra.business;

public class ServicioContabilidad {
	
	// FACTORIA DINAMICA
	// Metodo dinamico y publico que retorna una instancia
	public Contabilidad getLibroContable() {
		return Contabilidad.getInstance();
	}

}

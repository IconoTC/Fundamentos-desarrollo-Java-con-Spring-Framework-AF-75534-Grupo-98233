package app.persistencia;

import app.modelo.Persona;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;


public class PersonaDAO extends NamedParameterJdbcDaoSupport{

    private RowMapper<Persona> mapeadorPersona;

    public List<Persona> mostrarTodos(){
        return getNamedParameterJdbcTemplate().query("select * from APP.PERSONAS", (Map<String,Object>)null, mapeadorPersona);
    }

    public Persona consultarPersona(String dni){
        String sql = "select * from APP.PERSONAS where DNI=:nif";
        Map<String,Object> parametros = new HashMap<String, Object>();
        parametros.put("nif", dni);
        return getNamedParameterJdbcTemplate().queryForObject(sql, parametros, mapeadorPersona);
    }

    public void altaPersona(Persona p){
        String sql = "insert into APP.PERSONAS values (:d,:n,:f,:dir,:t)";
        Map<String,Object> parametros = new HashMap<String, Object>();
        parametros.put("d", p.getDni());
        parametros.put("n", p.getNombre());
        parametros.put("f", p.getFechaNac());
        parametros.put("dir", p.getDireccion());
        parametros.put("t", p.getTelefono());

        getNamedParameterJdbcTemplate().update(sql, parametros);
    }

    public void bajaPersona(String dni){
        String sql = "delete from APP.PERSONAS where DNI=:nif";
        Map<String,Object> parametros = new HashMap<String, Object>();
        parametros.put("nif", dni);
        getNamedParameterJdbcTemplate().update(sql, parametros);
    }

    public void modificarDireccion(String dni, String nuevaDireccion){
        String sql = "update APP.PERSONAS set DIR=:d where DNI=:nif ";
        Map<String,Object> parametros = new HashMap<String, Object>();
        parametros.put("d", nuevaDireccion);
        parametros.put("nif", dni);
        getNamedParameterJdbcTemplate().update(sql, parametros);
    }

    public RowMapper<Persona> getMapeadorPersona() {
        return mapeadorPersona;
    }

    public void setMapeadorPersona(RowMapper<Persona> mapeadorPersona) {
        this.mapeadorPersona = mapeadorPersona;
    }

}

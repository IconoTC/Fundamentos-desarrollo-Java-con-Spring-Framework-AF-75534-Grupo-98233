package app.cliente;

import app.modelo.Persona;
import app.persistencia.PersonaDAO;
import java.sql.Date;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) {
        ApplicationContext contenedor =
                new ClassPathXmlApplicationContext("spring.xml");

        PersonaDAO dao = (PersonaDAO) contenedor.getBean("miDAO");

        Persona p1 = new Persona("111111111-A", "Juan", new Date(1997, 12, 20), "Gran Via, 12 Madrid", 616111111);
        Persona p2 = new Persona("111222222-B", "Maria", new Date(1990, 7, 2), "Mayor, 12 Madrid", 616222222);
        Persona p3 = new Persona("111333333-C", "Pedro", new Date(1993, 3, 12), "Castellana, 12 Madrid", 616333333);

        dao.altaPersona(p1);
        dao.altaPersona(p2);
        dao.altaPersona(p3);

        for(Persona p : dao.mostrarTodos())
            System.out.println(p);
        System.out.println("--------------------------------------");

        dao.modificarDireccion("111222222-B", "Alcala, 27 Madrid");

        for(Persona p : dao.mostrarTodos())
            System.out.println(p);
        System.out.println("--------------------------------------");

        dao.bajaPersona("111333333-C");

        for(Persona p : dao.mostrarTodos())
            System.out.println(p);
        System.out.println("--------------------------------------");

    }

}

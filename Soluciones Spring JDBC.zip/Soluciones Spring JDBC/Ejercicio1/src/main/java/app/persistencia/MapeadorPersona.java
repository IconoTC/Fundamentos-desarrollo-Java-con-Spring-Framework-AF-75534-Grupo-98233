package app.persistencia;

import app.modelo.Persona;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class MapeadorPersona implements RowMapper<Persona>{

    public Persona mapRow(ResultSet rs, int i) throws SQLException {
        Persona p = new Persona();
        p.setDni(rs.getString("DNI"));
        p.setNombre(rs.getString("NOMBRE"));
        p.setFechaNac(rs.getDate("FECNAC"));
        p.setDireccion(rs.getString("DIR"));
        p.setTelefono(rs.getInt("TFNO"));
        return p;
    }

}

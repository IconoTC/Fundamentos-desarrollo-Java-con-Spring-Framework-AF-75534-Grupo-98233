package app.persistencia;

import app.modelo.Persona;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class PersonaDAO extends JdbcDaoSupport{

    private RowMapper<Persona> mapeadorPersona;

    public List<Persona> mostrarTodos(){
        return getJdbcTemplate().query("select * from APP.PERSONAS", mapeadorPersona);
    }

    public Persona consultarPersona(String dni){
        String sql = "select * from APP.PERSONAS where DNI=?";
        return getJdbcTemplate().queryForObject(sql, new Object[] {dni}, mapeadorPersona);
    }

    public void altaPersona(Persona p){
        String sql = "insert into APP.PERSONAS values (?,?,?,?,?)";
        getJdbcTemplate().update(sql, p.getDni(), p.getNombre(), p.getFechaNac(), p.getDireccion(), p.getTelefono());
    }

    public void bajaPersona(String dni){
        String sql = "delete from APP.PERSONAS where DNI=?";
        getJdbcTemplate().update(sql, dni);
    }

    public void modificarDireccion(String dni, String nuevaDireccion){
        String sql = "update APP.PERSONAS set DIR=? where DNI=? ";
        getJdbcTemplate().update(sql, nuevaDireccion, dni);
    }

    public RowMapper<Persona> getMapeadorPersona() {
        return mapeadorPersona;
    }

    public void setMapeadorPersona(RowMapper<Persona> mapeadorPersona) {
        this.mapeadorPersona = mapeadorPersona;
    }

}

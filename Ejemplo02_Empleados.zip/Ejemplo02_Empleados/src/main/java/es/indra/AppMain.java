package es.indra;

// ctrl + shift + o
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el applicationContext.xml y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(contenedor.getBean("empleado1"));
		System.out.println(contenedor.getBean("empleado2"));
		System.out.println(contenedor.getBean("empleado3"));
		System.out.println(contenedor.getBean("empleado4"));
		System.out.println(contenedor.getBean("empleado5"));
	}

}

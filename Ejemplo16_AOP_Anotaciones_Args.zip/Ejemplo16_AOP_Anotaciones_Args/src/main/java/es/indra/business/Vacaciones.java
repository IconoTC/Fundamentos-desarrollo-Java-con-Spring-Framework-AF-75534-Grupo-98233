package es.indra.business;

import org.springframework.stereotype.Component;

@Component
public class Vacaciones {
	
	public void viajar(String numVuelo) throws RuntimeException{
		System.out.println("Nos vamos de vacaciones en el Vuelo " + numVuelo);
		throw new RuntimeException("Error **************");
	}

}

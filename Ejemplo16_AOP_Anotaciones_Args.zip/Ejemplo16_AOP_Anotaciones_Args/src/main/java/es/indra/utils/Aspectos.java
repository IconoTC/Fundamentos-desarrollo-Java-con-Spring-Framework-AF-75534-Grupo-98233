package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;

@Service
@Aspect
@EnableAspectJAutoProxy
public class Aspectos {
	
	// Como  no puedo poner mas de un punto de corte en la clase
	// los declaro sobre cada aspecto
	
	
	// El argumento debe llamarse igual que el recibido en el metodo
	@Before(value = "execution (* es.indra.business.Vacaciones.viajar(..)) && args(nVuelo)")
	public void a_facturar(String nVuelo) {
		System.out.println("Facturando " + nVuelo);
	}
	
	@Before("bean(vacaciones)")
	public void b_pasarControl() {
		System.out.println("Pasando control");
	}
	
	@Before(value = "execution (* es.indra.business.Vacaciones.viajar(..)) && args(numeroVuelo)")
	public void c_embarcar(String numeroVuelo) {
		System.out.println("Embarcando " + numeroVuelo);
	}
	
	@Before("bean(vacaciones)")
	public void d_despegar() {
		System.out.println("Despegando");
	}
	
	@AfterReturning("bean(vacaciones)")
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
		
	@After("bean(vacaciones)")
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	@AfterThrowing(pointcut = "bean(vacaciones)", throwing = "ex")
	public void emergencia(Exception ex) {
		System.out.println("Emergencia a bordo");
		System.out.println(ex.getMessage());
	}
	
	@Around("bean(vacaciones) && args(vuelo)")
	public void medirTiempo(ProceedingJoinPoint pjp, String vuelo) throws Throwable {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomado el tiempo de inicio del vuelo " + vuelo);
		
		pjp.proceed();
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomado el tiempo final del vuelo " + vuelo);
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}

package es.indra.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import es.indra.models.Persona;

public class MapeadorPersona implements RowMapper<Persona>{

    public Persona mapRow(ResultSet rs, int i) throws SQLException {
        Persona p = new Persona();
        p.setDni(rs.getString("DNI"));
        p.setNombre(rs.getString("NOMBRE"));
        p.setFechaNac(rs.getDate("FECNAC"));
        p.setDireccion(rs.getString("DIR"));
        p.setTelefono(rs.getInt("TFNO"));
        return p;
    }

}

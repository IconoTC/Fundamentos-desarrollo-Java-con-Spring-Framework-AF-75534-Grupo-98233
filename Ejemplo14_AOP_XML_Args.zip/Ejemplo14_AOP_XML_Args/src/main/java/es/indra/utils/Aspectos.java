package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;

public class Aspectos {
	
	// Observar que el nombre del parametro no se llama igual que en la clase Vacaciones
	public void facturar(String nVuelo) {
		System.out.println("Facturando " + nVuelo);
	}
	
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	public void embarcar(String numeroVuelo) {
		System.out.println("Embarcando " + numeroVuelo);
	}
	
	public void pasarControl() {
		System.out.println("Pasando control");
	}
	
	public void despegar() {
		System.out.println("Despegando");
	}
	
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	public void emergencia(Exception ex) {
		System.out.println("Emergencia a bordo");
		System.out.println(ex.getMessage());
	}
	
	public void medirTiempo(ProceedingJoinPoint pjp, String vuelo) throws Throwable {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomado el tiempo de inicio del vuelo " + vuelo);
		
		pjp.proceed();
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomado el tiempo final del vuelo " + vuelo);
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}

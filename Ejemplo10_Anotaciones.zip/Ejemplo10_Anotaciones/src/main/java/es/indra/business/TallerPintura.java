package es.indra.business;

import org.springframework.stereotype.Service;

import es.indra.models.Coche;

// Si no ponemos nombre, coge el nombre de la clase con la primera letra en minuscula
//@Service
@Service("tallerPintura")
public class TallerPintura implements ITaller{

	@Override
	public void reparar(Coche coche) {
		System.out.println("En el taller de pintura se pinta el coche " + coche);
	}

}

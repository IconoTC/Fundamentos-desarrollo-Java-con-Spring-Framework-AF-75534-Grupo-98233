package es.indra.models;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
@Lazy
public class Coche {
	
	// Inyeccion por propiedad
	//@Value("1234-NLD")
	private String matricula;
	
	//@Value("A5")
	private String modelo;
	
	public Coche() {
		// TODO Auto-generated constructor stub
	}

	// Inyeccion por constructor
	public Coche(@Value("1234-NLD") String matricula, @Value("A5") String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", modelo=" + modelo + "]";
	}
	
	
	

}

package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import es.indra.entities.Producto;

// Spring Boot detecta que heredamos de xxxRepository y entonces genera un bean de ProductosDAO
public interface ProductosDAO extends JpaRepository<Producto, Integer>{
	
}

package es.indra.business;

import java.util.List;

import es.indra.entities.Producto;

public interface IProductosBS {
	
	public List<Producto> consultarTodos();
	
	public Producto buscarProducto(int id);
	
	public boolean insertarProducto(Producto producto);
	
	public boolean eliminarProducto(int id);
	
	public Producto modificarProducto(Producto producto);

}

package es.indra.business;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(int id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = SQLException.class)
	public boolean insertarProducto(Producto producto) {
		Producto insertado = dao.save(producto);
		return insertado != null;
	}

	@Override
	public boolean eliminarProducto(int id) {
		dao.deleteById(id);
		return true;
	}

	@Override
	public Producto modificarProducto(Producto producto) {
		return  dao.save(producto);
	}

}

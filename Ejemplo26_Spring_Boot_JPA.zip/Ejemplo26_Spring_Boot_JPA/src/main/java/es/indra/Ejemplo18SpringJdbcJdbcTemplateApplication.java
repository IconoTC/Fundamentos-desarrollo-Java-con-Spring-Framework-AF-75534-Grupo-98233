package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo18SpringJdbcJdbcTemplateApplication implements CommandLineRunner{
	
	@Autowired
	private IProductosBS bs;

	// En los proyectos con Spring Boot, el metodo main esta dedicado
	// exclusivamente a levantar el contexto de Spring (crear el contenedor con los beans declarados)
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18SpringJdbcJdbcTemplateApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	@Override
	public void run(String... args) throws Exception {
		
		// Insertar un producto
		bs.insertarProducto(new Producto(0, "Prueba", 123));
		
		// Elimino el producto 4
		bs.eliminarProducto(4);
		
		// Modificar el producto 1
		bs.modificarProducto(new Producto(1, "Pantalla", 143.95));
		
		// Consultar todos los productos
		bs.consultarTodos().forEach(System.out::println);
		System.out.println("--------------------------");
		
		// Buscar un producto
		System.out.println(bs.buscarProducto(2));
		System.out.println("--------------------------");
		
	}

}

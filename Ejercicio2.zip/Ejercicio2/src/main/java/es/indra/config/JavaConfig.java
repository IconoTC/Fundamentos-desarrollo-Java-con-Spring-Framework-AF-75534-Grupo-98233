package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import es.indra.persistence.MapeadorPersona;
import es.indra.persistence.PersonaDAO;

@Configuration
public class JavaConfig {
	
	@Bean
	public DriverManagerDataSource miDataSource() {
		// datos de conexion
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:~/test");
		return dataSource;
	}
	
	@Bean
	public NamedParameterJdbcTemplate template() {
		return new NamedParameterJdbcTemplate(miDataSource());
	}
	
	@Bean
	public MapeadorPersona mapeadorPersona() {
		return new MapeadorPersona();
	}
	
	@Bean
	public PersonaDAO dao() {
		PersonaDAO dao = new PersonaDAO();
		dao.setPlantilla(template());
		dao.setMapeadorPersona(mapeadorPersona());
		return dao;
	}

}

package es.indra;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Persona;
import es.indra.persistence.PersonaDAO;

@SpringBootApplication
public class Main implements CommandLineRunner {

	@Autowired
	private PersonaDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		dao.crearTabla();
		
		Persona p1 = new Persona("6666666-F", "Elena", new Date(1997, 12, 20), "Gran Via, 12 Madrid", 616666666);	
		dao.altaPersona(p1);
		

		for (Persona p : dao.mostrarTodos())
			System.out.println(p);
		System.out.println("--------------------------------------");

		dao.modificarDireccion("6666666-F", "Alcala, 27 Madrid");

		for (Persona p : dao.mostrarTodos())
			System.out.println(p);
		System.out.println("--------------------------------------");

		dao.bajaPersona("6666666-F");

		for (Persona p : dao.mostrarTodos())
			System.out.println(p);
		System.out.println("--------------------------------------");

	}

}

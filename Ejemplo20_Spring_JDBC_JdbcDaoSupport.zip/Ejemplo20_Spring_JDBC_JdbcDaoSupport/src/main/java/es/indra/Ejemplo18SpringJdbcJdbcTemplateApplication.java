package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo18SpringJdbcJdbcTemplateApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	// En los proyectos con Spring Boot, el metodo main esta dedicado
	// exclusivamente a levantar el contexto de Spring (crear el contenedor con los beans declarados)
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18SpringJdbcJdbcTemplateApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	@Override
	public void run(String... args) throws Exception {
		// Crear la tabla y los datos iniciales
		dao.crearTabla();
		
		// Insertar nuevo producto
		dao.insertarProducto(new Producto(6, "Prueba", 456));
		
		// Consultar todos los productos
		dao.consultarTodos().forEach(System.out::println);
		
		// Buscar un producto
		System.out.println(dao.buscarProducto(4) + "------");
		
	}

}

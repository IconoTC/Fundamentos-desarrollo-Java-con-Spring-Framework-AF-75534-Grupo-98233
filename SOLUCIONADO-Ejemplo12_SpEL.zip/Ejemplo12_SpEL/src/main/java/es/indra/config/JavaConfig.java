package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.models.Cliente;

@Configuration
public class JavaConfig {
	
	/*
	 * crear 3 beans de cliente:
	 * 		crear cliente1
	 * 		crear cliente2 podeis utilizar propiedades del cliente1
	 * 		crear cliente3
	 * 
	 * crear un bean de la clase Pruebas:
	 * 		valorContador = incrementarContador() de Cliente
	 * 		importeCompras = si la cifraCompras del cliente1 es mayor que 12000000 le asignas esa y sino 12000000
	 * 		clientes = lista con los 3 clientes
	 * 
	 * crear un bean de la clase OperacionColecciones:
	 * 		mejoresClientes = cuya cifraCompras sea superior a 10 millones
	 * 		mejorCompra = cliente con la mejor cifraCompras
	 * 		peorCompra = cliente con la peor cifraCompras
	 * 		datos = proyeccion (nombre | nif)
	 * */
	
	@Bean
	public Cliente cliente1() {
		return new Cliente("Juan", false, "B-12345678", 16_000_000);
	}
	
	// Al final utilizo este cliente2 porque al utilizar SpEL en la clase Cliente
	// lo que ocurre es que estoy modificando todas las propiedades de los 3 beans cliente.
	@Bean
	public Cliente cliente2() {
		return new Cliente("Maria", false, "B-98765456", 6_000_000);
	}
	
	@Bean
	public Cliente cliente3() {
		return new Cliente("Pedro", true, "B-55665445", 12_000_000);
	}
	
	
	

}

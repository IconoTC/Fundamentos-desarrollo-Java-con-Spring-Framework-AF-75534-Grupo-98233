package es.indra;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.OperacionColecciones;
import es.indra.business.Pruebas;
import es.indra.config.JavaConfig;
import es.indra.models.Cliente;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el JavaConfig.class y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		AnnotationConfigApplicationContext contenedor = new AnnotationConfigApplicationContext(JavaConfig.class);
		contenedor.scan("es.indra");
		//contenedor.refresh();
		
		Pruebas pruebas = contenedor.getBean("pruebas", Pruebas.class);
		System.out.println("Valor del contador: " + pruebas.getValorContador());
		System.out.println("Importe Compras: " + pruebas.getImporteCompras());
		pruebas.getClientes().forEach(System.out::println);
		System.out.println("-------------------------");

		
		OperacionColecciones opColecciones = contenedor.getBean("operacionColecciones", OperacionColecciones.class);
		opColecciones.getMejoresClientes().forEach(System.out::println);
		System.out.println("-------------------------");
		
		opColecciones.getDatos().forEach(System.out::println);
		System.out.println("-------------------------");
		
		System.out.println("Mejor: " +  opColecciones.getMejorCompra());
		System.out.println("Peor: " +  opColecciones.getPeorCompra());
		
	}

}

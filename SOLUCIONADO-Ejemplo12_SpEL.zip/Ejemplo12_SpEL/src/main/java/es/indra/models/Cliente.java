package es.indra.models;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component("cliente2")
public class Cliente {

	//@Value("#{'Maria'}")
	private String nombre;
	
	//@Value("#{cliente1.nuevo}")
	private boolean nuevo;
	
	//@Value("#{cliente1.nif ?: 'xxxxxxx'}")
	private String nif;
	
	//@Value("#{cliente1.cifraCompras * 1.1}")
	private double cifraCompras;
	
	// recurso estatico
	private static int contador = 1;

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nombre, boolean nuevo, String nif, double cifraCompras) {
		super();
		this.nombre = nombre;
		this.nuevo = nuevo;
		this.nif = nif;
		this.cifraCompras = cifraCompras;
	}
	
	// metodo estatico
	public static int incrementarContador() {
		return ++contador;
	}
	
	// metodo estatico
	public static int getContador() {
		return contador;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public boolean isNuevo() {
		return nuevo;
	}

	public void setNuevo(boolean nuevo) {
		this.nuevo = nuevo;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public double getCifraCompras() {
		return cifraCompras;
	}

	public void setCifraCompras(double cifraCompras) {
		this.cifraCompras = cifraCompras;
	}

	@Override
	public String toString() {
		return "Cliente [nombre=" + nombre + ", nuevo=" + nuevo + ", nif=" + nif + ", cifraCompras=" + cifraCompras
				+ "]";
	}

}

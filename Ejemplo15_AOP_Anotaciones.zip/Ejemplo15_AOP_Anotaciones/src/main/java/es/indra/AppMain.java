package es.indra;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Vacaciones;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el applicationContext.xml y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		AnnotationConfigApplicationContext contenedor = new AnnotationConfigApplicationContext();
		contenedor.scan("es.indra");
		contenedor.refresh();
		
		Vacaciones vacaciones = contenedor.getBean("vacaciones", Vacaciones.class);
		vacaciones.viajar();
	}

}

package es.indra;

// ctrl + shift + o
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el applicationContext.xml y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empleado empl1Singleton = contenedor.getBean("empleado1", Empleado.class);
		Empleado empl2Singleton = contenedor.getBean("empleado1", Empleado.class);
		System.out.println("Es el mismo objeto con singleton " + (empl1Singleton == empl2Singleton));
		
		
		Empleado empl1Prototype = contenedor.getBean("empleado2", Empleado.class);
		Empleado empl2Prototype = contenedor.getBean("empleado2", Empleado.class);
		System.out.println("Es el mismo objeto con prototype " + (empl1Prototype == empl2Prototype));
		
	}

}

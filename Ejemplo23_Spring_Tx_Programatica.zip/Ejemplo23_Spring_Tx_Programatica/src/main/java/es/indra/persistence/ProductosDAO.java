package es.indra.persistence;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import es.indra.models.Producto;

public class ProductosDAO {
	
	private JdbcTemplate template;
	private RowMapper<Producto> mapeadorProducto;
	private TransactionTemplate txTemplate;
	
	
	public List<Producto> consultarTodos(){
		return template.query("select * from PRODUCTOS", mapeadorProducto);
	}
	
	public Producto buscarProducto(int id){
		return template.queryForObject("select * from PRODUCTOS where ID=?", mapeadorProducto, id);
	}

	public boolean insertarProducto(Producto producto) {
		//boolean insertado = false;
		
		txTemplate.execute(new TransactionCallbackWithoutResult() {
			
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				try {
					String sql = "insert into PRODUCTOS values (?,?,?)";
					
					// Producto bueno
					template.update(sql, producto.getID(), producto.getDescripcion(), producto.getPrecio());
					
					// Producto erroneo
					template.update(sql, 2, "Producto erroneo", 123);
					
					System.out.println("Se efectua el commit");
			
					System.out.println("Producto insertado");
				
				} catch (Exception ex) {
					// Ordenar el rollback
					status.setRollbackOnly();
					System.out.println("Se ordena el rollback");
					ex.printStackTrace();
				}		
			}
		});
		
		
		return true;
	}
	
	public void crearTabla() {		
		// Crear la tabla
		template.update("DROP TABLE PRODUCTOS if exists");
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		template.update(sql);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (?,?,?)";
		for (int i = 1; i <= 5; i++) {
			template.update(sql, i, "Producto " + i, i * 100);
		}
	}
	
	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

	public TransactionTemplate getTxTemplate() {
		return txTemplate;
	}

	public void setTxTemplate(TransactionTemplate txTemplate) {
		this.txTemplate = txTemplate;
	}
	
}

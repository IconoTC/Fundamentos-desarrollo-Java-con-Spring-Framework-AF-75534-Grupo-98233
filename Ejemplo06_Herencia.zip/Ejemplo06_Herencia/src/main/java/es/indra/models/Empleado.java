package es.indra.models;

public class Empleado {

	private int numEmpleado;
	private String nombre;
	private String apellido;
	private boolean jefe;
	private double sueldo;

	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(int numEmpleado, String nombre, String apellido, boolean jefe, double sueldo) {
		super();
		this.numEmpleado = numEmpleado;
		this.nombre = nombre;
		this.apellido = apellido;
		this.jefe = jefe;
		this.sueldo = sueldo;
	}

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public boolean isJefe() {
		return jefe;
	}

	public void setJefe(boolean jefe) {
		this.jefe = jefe;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [numEmpleado=" + numEmpleado + ", nombre=" + nombre + ", apellido=" + apellido + ", jefe="
				+ jefe + ", sueldo=" + sueldo + "]";
	}

}

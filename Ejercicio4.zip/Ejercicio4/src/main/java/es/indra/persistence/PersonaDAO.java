package es.indra.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import es.indra.models.Persona;

public class PersonaDAO extends NamedParameterJdbcDaoSupport{

    
    private RowMapper<Persona> mapeadorPersona;

    public List<Persona> mostrarTodos(){
        return getNamedParameterJdbcTemplate().query("select * from PERSONAS", mapeadorPersona);
    }

    public Persona consultarPersona(String dni){
        String sql = "select * from PERSONAS where DNI=:dni";
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("dni", dni);
        return getNamedParameterJdbcTemplate().queryForObject(sql, parametros, mapeadorPersona);
    }

    public void altaPersona(Persona persona){
        String sql = "insert into PERSONAS values (:dni, :nombre, :fecha, :dir, :tfno)";
        
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("dni", persona.getDni());
        parametros.put("nombre", persona.getNombre());
        parametros.put("fecha", persona.getFechaNac());
        parametros.put("dir", persona.getDireccion());
        parametros.put("tfno", persona.getTelefono());
        
        getNamedParameterJdbcTemplate().update(sql, parametros);
    }

    public void bajaPersona(String dni){
        String sql = "delete from PERSONAS where DNI=:dni";
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("dni", dni);
        
        getNamedParameterJdbcTemplate().update(sql, parametros);
    }

    public void modificarDireccion(String dni, String nuevaDireccion){
        String sql = "update PERSONAS set DIR=:dir where DNI=:dni ";
        
        Map<String, Object> parametros = new HashMap<>();
        parametros.put("dni", dni);
        parametros.put("dir", nuevaDireccion);
        
        getNamedParameterJdbcTemplate().update(sql, parametros);
    }
    
    public void crearTabla() {		
		// Crear la tabla
    	getNamedParameterJdbcTemplate().update("DROP TABLE PERSONAS if exists", (Map<String, Object>) null);
		String sql = "CREATE TABLE PERSONAS " + "(DNI VARCHAR(15) not NULL, " + "NOMBRE VARCHAR(45), "
				+ "FECNAC DATE, DIR VARCHAR(45), TFNO INTEGER," + "PRIMARY KEY (DNI) )";
		getNamedParameterJdbcTemplate().update(sql, (Map<String, Object>) null);

		// Crear 5 personas en la tabla
//		sql = "insert into PERSONAS values (?,?,?,?,?)";
//		plantilla.update(sql, "1111111-A", "Juan", new Date("10/12/1987"), "Real, 27 Madrid", 616111111);
//		plantilla.update(sql, "2222222-B", "Maria", new Date("1/2/1989"), "Diagonal, 87 Barcelona", 616222222);
//		plantilla.update(sql, "3333333-C", "Pedro", new Date("12/9/2001"), "Mayor, 31 Toledo", 616333333);
//		plantilla.update(sql, "4444444-D", "Marta", new Date("16/4/2006"), "Camino, 68 Coruña", 616444444);
//		plantilla.update(sql, "5555555-E", "Alvaro", new Date("14/3/2003"), "Alfonso, 22 Ciudad Real", 616555555);
		
	}

    public RowMapper<Persona> getMapeadorPersona() {
        return mapeadorPersona;
    }

    public void setMapeadorPersona(RowMapper<Persona> mapeadorPersona) {
        this.mapeadorPersona = mapeadorPersona;
    }


}

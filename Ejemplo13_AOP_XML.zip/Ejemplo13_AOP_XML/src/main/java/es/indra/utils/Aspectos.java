package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;

public class Aspectos {
	
	public void facturar() {
		System.out.println("Facturando");
	}
	
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	public void embarcar() {
		System.out.println("Embarcando");
	}
	
	public void pasarControl() {
		System.out.println("Pasando control");
	}
	
	public void despegar() {
		System.out.println("Despegando");
	}
	
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	public void emergencia(Exception ex) {
		System.out.println("Emergencia a bordo");
		System.out.println(ex.getMessage());
	}
	
	public void medirTiempo(ProceedingJoinPoint pjp) throws Throwable {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomado el tiempo de inicio");
		
		pjp.proceed();
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomado el tiempo final");
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}

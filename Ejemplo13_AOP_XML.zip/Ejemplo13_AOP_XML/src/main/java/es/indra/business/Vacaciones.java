package es.indra.business;

public class Vacaciones {
	
	public void viajar() throws RuntimeException{
		System.out.println("Nos vamos de vacaciones");
		throw new RuntimeException("Error **************");
	}

}

package es.indra.models;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

public class Empleado implements InitializingBean, DisposableBean{

	private int numEmpleado;
	private String nombre;
	private String apellido;
	private boolean jefe;
	private double sueldo;

	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(int numEmpleado, String nombre, String apellido, boolean jefe, double sueldo) {
		super();
		this.numEmpleado = numEmpleado;
		this.nombre = nombre;
		this.apellido = apellido;
		this.jefe = jefe;
		this.sueldo = sueldo;
	}
	
	// ---- Orden de ejecucion de los metodos de ciclo de vida:
	//   1.-  los metodos anotados
	//   2.-  los metodos de las interfaces InitializingBean y DisposableBean
	//   3.-  los metodos propios
	
	// ********************* Metodos propios de ciclo de vida *********************
	public void metodoInit() {
		System.out.println("init - se ha creado el bean");
	}
	
	public void metodoDestroy() {
		System.out.println("destroy - se va a eliminar el bean");
	}
	
	// ********************* Metodos implementados de las interfaces de ciclo de vida *********************
	@Override
	public void afterPropertiesSet() throws Exception {   // InitializingBean
		System.out.println("InitializingBean - afterPropertiesSet - se han inyectado las propiedades del bean");
	}
	
	@Override
	public void destroy() throws Exception {  // DisposableBean
		System.out.println("DisposableBean - destroy - se va a eliminar el bean");	
	}
	
	// ********************* Metodos anotados **************************
	@PostConstruct
	public void postConstruct(){
		System.out.println("@PostConstruct - se ha creado el bean");
	}
	
	@PreDestroy
	public void preDestroy() {
		System.out.println("@PreDestroy - se va a eliminar el bean");
	}
	

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public boolean isJefe() {
		return jefe;
	}

	public void setJefe(boolean jefe) {
		this.jefe = jefe;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [numEmpleado=" + numEmpleado + ", nombre=" + nombre + ", apellido=" + apellido + ", jefe="
				+ jefe + ", sueldo=" + sueldo + "]";
	}

}

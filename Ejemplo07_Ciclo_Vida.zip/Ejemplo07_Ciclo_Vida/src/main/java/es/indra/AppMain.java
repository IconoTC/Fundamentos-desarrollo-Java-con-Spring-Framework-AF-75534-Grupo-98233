package es.indra;

import java.util.stream.Stream;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empresa;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer el applicationContext.xml y por cada bean declarado
		// se genera una instancia y se guarda en el contenedor
		AbstractApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empresa empresa = (Empresa) contenedor.getBean("empresa");
		
		System.out.println("------- Empleados --------");
		empresa.getEmpleados().forEach(System.out::println);
		
		System.out.println("------- Proyectos --------");
		empresa.getProyectos().forEach(System.out::println);
		
		System.out.println("------- Equipo --------");
		Stream.of(empresa.getEquipo()).forEach(System.out::println);
		
		System.out.println("------- Jefes de Proyecto --------");
		empresa.getJefesProyecto().entrySet().forEach(System.out::println);
		
		System.out.println("------- Emails --------");
		empresa.getEmails().entrySet().forEach(System.out::println);
		
		// Eliminar todos los beans del contenedor
		contenedor.registerShutdownHook();
	}

}

// ctrl + shift + f